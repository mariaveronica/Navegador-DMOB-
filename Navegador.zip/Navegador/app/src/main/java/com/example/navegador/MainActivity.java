package com.example.navegador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btnavegador;
    private EditText edtexto;
    private WebView navegadorWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnavegador=(Button) findViewById(R.id.botaoDeEntrarNoSite);
        edtexto=(EditText) findViewById(R.id.colocarUrl);
        navegadorWeb=(WebView) findViewById(R.id.navegadorDaWeb);

        btnavegador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navegadorWeb.loadUrl(edtexto.getText().toString();
            }
        });



    }
}
